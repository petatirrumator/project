#include "header/raylib.h"
#include "header/raymath.h"
#include <iostream>

// make the new animation and initialize it with the given parameters and return the animation
// will bind the given parameters to an animation object
Animation init_animation(const Texture2D &texture, const int &frames_in_sheet, int &frame_speed, Vector2 &position);

void update_animation(Animation &anim, const int &fps);
void draw_animation(const Animation &anim, const int &screen_width, const int &screen_height);

// face the frame_rec to the right i.e with +ve width
void face_animation_right(Animation &anim);
void face_animation_left(Animation &anim);

bool out_of_bound(const Rectangle &rect, const int &screen_width, const int &screen_height);

// modifies the position by the given amount key is pressed
void move_left(Vector2 &position, const float &amount);
void move_right(Vector2 &position, const float &amount);
void move_up(Vector2 &position, const float &amount);
void move_down(Vector2 &position, const float &amount);

// detects movement after doing so modifies the position and returns true if movement is detected
bool move_character(Vector2 &character_position, Animation &character_run_anim);

bool attack1(); // returns true if key for attack 1 is pressed
bool attack2(); // returns true if key for attack 2 is pressed
bool guard();   // returns true if key for guard is pressed

void game(const int &screen_width, const int &screen_height, const int &fps);

void game_loop(const int &screen_width, const int &screen_height, const int &fps,
               Vector2 &character_position, Animation **&character_animations, Texture2D &background, Animation **&trees_animations, Animation **&bushes_animations,
               Animation **&sheeps_animations);

void update_frame_counter(Animation **&animations, const int &num_animations);
void update_animations_type(Animation **&animations, const int &num_animations, const int &fps);

void draw_animations_type(Animation **&animations, const int &num_animations, const int &screen_width, const int &screen_height);

void update_moving_sheep(Animation &moving_sheep, const int &screen_width, const int &screen_height, float &sheep_speed_X);

int main()
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 1200;
    const int screenHeight = 600;
    const int fps = 60;

    InitWindow(screenWidth, screenHeight, "Yellow Knight");
    SetTargetFPS(fps); // game loop will run only 60 times per second

    game(screenWidth, screenHeight, fps);

    CloseWindow(); // Close window and OpenGL context

    return 0;
}

Animation init_animation(const Texture2D &texture, const int &frames_in_sheet, int &frame_speed, Vector2 &position)
{
    Animation new_animation = {
        texture,
        frames_in_sheet,
        frame_speed,
        position};

    // now we initialize the parameters that are required for drawing
    new_animation.frame_rec.x = 0;
    new_animation.frame_rec.y = 0;
    // get the width of the frame rectangle
    new_animation.frame_rec.width = (float)new_animation.texture.width / new_animation.frames_in_sheet;
    new_animation.frame_rec.height = (float)new_animation.texture.height;

    new_animation.frame_counter = 0;
    new_animation.current_frame = 0;
    new_animation.face_right = true; // make sure sprites are facing right

    return new_animation;
}

void update_animation(Animation &anim, const int &fps)
{
    // first we check if the animation needs to be updated
    if (anim.frame_counter >= (fps / anim.frame_speed))
    {
        anim.frame_counter = 0;
        anim.current_frame++;

        // if we have reached the last frame in the sprite sheet then we reset
        // also the count starts from 0
        if (anim.current_frame > anim.frames_in_sheet - 1)
            anim.current_frame = 0;

        // below is a direct translation of:
        // frameRec.x = (float)currentFrame * (float)scarfy.width / 6;
        // move the x co-ordinate of the frame_rec to the next sheet in the sprite
        anim.frame_rec.x = (float)anim.current_frame * (float)anim.texture.width / anim.frames_in_sheet;
    }
}

void draw_animation(const Animation &anim, const int &screen_width, const int &screen_height)
{
    // first check if the right most position vector is out of bound for the screen
    // a rectangle around the animation

    Rectangle anim_rectangle = {
        anim.position.x,
        anim.position.y,
        anim.frame_rec.width,
        anim.frame_rec.height};

    if (out_of_bound(anim_rectangle, screen_width, screen_height) == true)
    {
        // it’s at least partially off‑screen…
        anim_rectangle.x = Clamp(anim_rectangle.x, 0.0f, screen_width - anim_rectangle.width);
        anim_rectangle.y = Clamp(anim_rectangle.y, 0.0f, screen_height - anim_rectangle.height);

        // set the animation position too
        anim.position.x = anim_rectangle.x;
        anim.position.y = anim_rectangle.y;

        // now it'll be fully on‑screen
    }
    DrawTextureRec(anim.texture, anim.frame_rec, anim.position, WHITE);
}

void face_animation_right(Animation &anim)
{

    anim.face_right = true;
    if (anim.frame_rec.width > 0.0f)
    {
        return;
    }
    else
    {
        anim.frame_rec.width *= -1.0f;
    }
}

void face_animation_left(Animation &anim)
{

    anim.face_right = false;
    if (anim.frame_rec.width < 0.0f)
    {
        return;
    }
    else
    {
        anim.frame_rec.width *= -1.0f;
    }
}

// returns true if the given rectangle goes out of bound of the screen
bool out_of_bound(const Rectangle &rect, const int &screen_width, const int &screen_height)
{

    bool offLeft = (rect.x < 0);
    bool offRight = (rect.x + rect.width > screen_width);
    bool offTop = (rect.y < 0);
    bool offBottom = (rect.y + rect.height > screen_height);

    if (offLeft || offRight || offTop || offBottom)
        return true;

    return false;
}

void move_left(Vector2 &position, const float &amount)
{
    position.x -= amount;
}

void move_right(Vector2 &position, const float &amount)
{
    position.x += amount;
}

void move_up(Vector2 &position, const float &amount)
{

    position.y -= amount; // up is -ve
}
void move_down(Vector2 &position, const float &amount)
{
    position.y += amount; // down is +ve
}

bool move_character(Vector2 &character_position, Animation &character_run_anim)
{

    bool key_pressed = false;
    // not in else if to enable diagonal movement
    if (IsKeyPressed(KEY_D) || IsKeyDown(KEY_D))
    {
        face_animation_right(character_run_anim);
        move_right(character_position, 5.0f);
        key_pressed = true;
    }
    if (IsKeyPressed(KEY_A) || IsKeyDown(KEY_A))
    {
        face_animation_left(character_run_anim);
        move_left(character_position, 5.0f);
        key_pressed = true;
    }
    if (IsKeyPressed(KEY_W) || IsKeyDown(KEY_W))
    {
        move_up(character_position, 5.0f);
        key_pressed = true;
    }
    if (IsKeyPressed(KEY_S) || IsKeyDown(KEY_S))
    {
        move_down(character_position, 5.0f);
        key_pressed = true;
    }

    if (key_pressed == true)
        return true;

    return false;
}

// returns true if key for attack 1 is pressed
bool attack1()
{
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || IsMouseButtonDown(MOUSE_BUTTON_LEFT))
        return true;
    return false;
}

// returns true if key for attack 2 is pressed
bool attack2()
{
    if (IsMouseButtonPressed(MOUSE_BUTTON_RIGHT) || IsMouseButtonDown(MOUSE_BUTTON_RIGHT))
        return true;
    return false;
}

void game(const int &screen_width, const int &screen_height, const int &fps)
{

    // NOTE: Textures MUST be loaded after Window initialization (OpenGL context is required)

    // initialize all the character stuff
    // NOTE: can't make this inside a function because otherwise the scope would be lost
    //--------------------------Character Stuff------------------//
    //  this vector would be common to all the character animations
    Vector2 character_position = {0.0f, 0.0f};

    // idle animation
    Texture2D character_idle = LoadTexture("assets/idle.png");
    int idle_total_frames = 8;
    int idle_speed = 14;
    Animation idle_anim = init_animation(character_idle, idle_total_frames, idle_speed, character_position);

    // run animation
    Texture2D character_run = LoadTexture("assets/run.png");
    int run_total_frames = 6;
    int run_speed = 12;
    Animation run_anim = init_animation(character_run, run_total_frames, run_speed, character_position);

    // attack1 animation
    Texture2D character_attack1 = LoadTexture("assets/attack1.png");
    int attack1_total_frames = 4;
    int attack1_speed = 10;
    Animation attack1_anim = init_animation(character_attack1, attack1_total_frames, attack1_speed, character_position);

    // attack2 animation
    Texture2D character_attack2 = LoadTexture("assets/attack2.png");
    int attack2_total_frames = 4;
    int attack2_speed = 10;
    Animation attack2_anim = init_animation(character_attack2, attack2_total_frames, attack2_speed, character_position);

    // guard animation
    Texture2D character_guard = LoadTexture("assets/guard.png");
    int guard_total_frames = 6;
    int guard_speed = 12;
    Animation guard_anim = init_animation(character_guard, guard_total_frames, guard_speed, character_position);

    // structure of character_animations is:
    //  index 0  : idle animation
    // index 1   : run animation
    // index 2   : attack1 animation
    // index 3   : attack2 animation
    // index 4   : guard animation
    // each index will have address of character animations
    Animation **character_animations = new Animation *[5];
    character_animations[0] = &idle_anim;
    character_animations[1] = &run_anim;
    character_animations[2] = &attack1_anim;
    character_animations[3] = &attack2_anim;
    character_animations[4] = &guard_anim;

    //-----------------------------------------------------------//

    // initialize all the environment stuff
    // NOTE: can't make this inside a function because otherwise the scope would be lost
    //--------------------------Environment Stuff------------------//
    Texture2D background = LoadTexture("assets/background.png"); // Texture loading

    Texture2D tree1 = LoadTexture("assets/tree1.png");
    int tree1_total_frames = 8;
    int tree1_speed = 8;
    Vector2 tree1_position = {100.f, 500.0f};
    Animation tree1_anim = init_animation(tree1, tree1_total_frames, tree1_speed, tree1_position);

    Texture2D tree2 = LoadTexture("assets/tree2.png");
    int tree2_total_frames = 8;
    int tree2_speed = 8;
    Vector2 tree2_position = {1000.f, 500.0f};
    Animation tree2_anim = init_animation(tree2, tree2_total_frames, tree2_speed, tree2_position);

    Texture2D tree3 = LoadTexture("assets/tree3.png");
    int tree3_total_frames = 8;
    int tree3_speed = 8;
    Vector2 tree3_position = {605.0f, 500.0f};
    Animation tree3_anim = init_animation(tree3, tree3_total_frames, tree3_speed, tree3_position);

    // structure of trees_animations is:
    //  index 0  : tree1 animation
    // index 1   : tree2 animation
    // each index will have address of trees_animations

    Animation **trees_animations = new Animation *[3];
    trees_animations[0] = &tree1_anim;
    trees_animations[1] = &tree2_anim;
    trees_animations[2] = &tree3_anim;
    //-----------------------------------------------------------//
    //---------BUSHES---------//
    Texture2D bush1 = LoadTexture("assets/bush1.png");
    int bush1_total_frames = 8;
    int bush1_speed = 8;
    Vector2 bush1_position = {700.f, 300.0f};
    Animation bush1_anim = init_animation(bush1, bush1_total_frames, bush1_speed, bush1_position);

    Texture2D bush2 = LoadTexture("assets/bush2.png");
    int bush2_total_frames = 8;
    int bush2_speed = 8;
    Vector2 bush2_position = {650.f, 260.0f};
    Animation bush2_anim = init_animation(bush2, bush2_total_frames, bush2_speed, bush2_position);

    Texture2D bush3 = LoadTexture("assets/bush3.png");
    int bush3_total_frames = 8;
    int bush3_speed = 8;
    Vector2 bush3_position = {150.f, 160.0f};
    Animation bush3_anim = init_animation(bush3, bush3_total_frames, bush3_speed, bush3_position);

    Texture2D bush4 = LoadTexture("assets/bush1.png");
    int bush4_total_frames = 8;
    int bush4_speed = 8;
    Vector2 bush4_position = {850.f, 90.0f};
    Animation bush4_anim = init_animation(bush4, bush4_total_frames, bush4_speed, bush4_position);

    Texture2D bush5 = LoadTexture("assets/bush3.png");
    int bush5_total_frames = 8;
    int bush5_speed = 8;
    Vector2 bush5_position = {950.f, 500.0f};
    Animation bush5_anim = init_animation(bush5, bush5_total_frames, bush5_speed, bush5_position);

    // structure of bushes_animations is:
    //  index 0  : tree1 animation
    // index 1   : tree2 animation
    // each index will have address of bush_animations

    Animation **bushes_animations = new Animation *[5];
    bushes_animations[0] = &bush1_anim;
    bushes_animations[1] = &bush2_anim;
    bushes_animations[2] = &bush3_anim;
    bushes_animations[3] = &bush4_anim;
    bushes_animations[4] = &bush5_anim;

    //-----------------------------------------------------------//

    //---------SHEEPS---------//
    Texture2D sheep1 = LoadTexture("assets/sheep_grass.png");
    int sheep1_total_frames = 12;
    int sheep1_speed = 12;
    Vector2 sheep1_position = {605.f, 250.0f};
    Animation sheep1_anim = init_animation(sheep1, sheep1_total_frames, sheep1_speed, sheep1_position);

    Texture2D sheep2 = LoadTexture("assets/sheep_idle.png");
    int sheep2_total_frames = 6;
    int sheep2_speed = 12;
    Vector2 sheep2_position = {550.f, 450.0f};
    Animation sheep2_anim = init_animation(sheep2, sheep2_total_frames, sheep2_speed, sheep2_position);

    Texture2D sheep3 = LoadTexture("assets/sheep_move.png");
    int sheep3_total_frames = 4;
    int sheep3_speed = 8;
    Vector2 sheep3_position = {250.f, 150.0f};
    Animation sheep3_anim = init_animation(sheep3, sheep3_total_frames, sheep3_speed, sheep3_position);

    Animation **sheeps_animations = new Animation *[3];
    sheeps_animations[0] = &sheep1_anim;
    sheeps_animations[1] = &sheep2_anim;
    sheeps_animations[2] = &sheep3_anim;

    //-----------------------------------------------------------//

    game_loop(screen_width, screen_height, fps,
              character_position, character_animations,
              background, trees_animations, bushes_animations, sheeps_animations);

    // De-Initialization
    //-----------------------------------------------------------//
    delete[] character_animations;
    character_animations = nullptr;
    delete[] trees_animations;
    trees_animations = nullptr;
    delete[] bushes_animations;
    bushes_animations = nullptr;
    delete[] sheeps_animations;
    sheeps_animations = nullptr;

    UnloadTexture(character_idle);
    UnloadTexture(character_run);
    UnloadTexture(character_attack1);
    UnloadTexture(character_attack2);
    UnloadTexture(character_guard);

    UnloadTexture(background);
    UnloadTexture(tree1);
    UnloadTexture(tree2);
    UnloadTexture(tree3);

    UnloadTexture(bush1);
    UnloadTexture(bush2);
    UnloadTexture(bush3);
    UnloadTexture(bush4);
    UnloadTexture(bush5);

    UnloadTexture(sheep1);
    UnloadTexture(sheep2);
    UnloadTexture(sheep3);
}

void game_loop(const int &screen_width, const int &screen_height, const int &fps,
               Vector2 &character_position, Animation **&character_animations, Texture2D &background, Animation **&trees_animations, Animation **&bushes_animations,
               Animation **&sheeps_animations)
{
    float sheep_speed_x = 1.0f;
    // Main game loop
    while (!WindowShouldClose()) // Detect window close button or ESC key
    {
        // Update
        //----------------------------------------------------------------------------------
        // frame counters keep track of speed of the animation
        // from the character only the idle animation's counter and update needs to be out here as it will run regardless
        update_frame_counter(character_animations, 1); // for character idle
        update_frame_counter(trees_animations, 3);     // for trees
        update_frame_counter(bushes_animations, 5);    // for bushes
        update_frame_counter(sheeps_animations, 3);    // for sheep

        // update the animation based on frame counter
        update_animations_type(character_animations, 1, fps);
        update_animations_type(trees_animations, 3, fps);
        update_animations_type(bushes_animations, 5, fps);
        update_animations_type(sheeps_animations, 3, fps);

        update_moving_sheep(*sheeps_animations[2], screen_width, screen_height, sheep_speed_x);

        // check for movement
        bool character_moved = move_character(character_position, *character_animations[1]);
        // check for attack
        bool character_attacked1 = attack1();
        bool character_attacked2 = attack2();
        // check for guard
        bool guarded = guard();

        // Draw The frame
        //----------------------------------------------------------------------------------

        BeginDrawing();

        DrawTexture(background, 0, 0, WHITE); // draw background
        // draw all the bushes
        draw_animations_type(bushes_animations, 5, screen_width, screen_height);

        // draw the first two sheeps
        draw_animations_type(sheeps_animations, 2, screen_width, screen_height);

        // draw the moving sheep
        draw_animation(*sheeps_animations[2], screen_width, screen_height);

        // DrawRectangleLines(sheeps_animations[2]->position.x, sheeps_animations[2]->position.y, sheeps_animations[2]->frame_rec.width, sheeps_animations[2]->frame_rec.height, WHITE);

        // std::cout << character_animations[0]->frame_rec.width << "\t" << character_animations[0]->frame_rec.height << std::endl;
        std::cout << "X: " << character_position.x << "\t Y: " << character_position.y << std::endl;

        if (character_moved == true) // run animation
        {
            character_animations[1]->frame_counter++;
            update_animation(*character_animations[1], fps);
            draw_animation(*character_animations[1], screen_width, screen_height);
        }
        else if (character_attacked1 == true) // attack 1 animation
        {
            (*character_animations[2]).frame_counter++;
            update_animation(*character_animations[2], fps);
            draw_animation(*character_animations[2], screen_width, screen_height);
        }
        else if (character_attacked2 == true) // attack 2 animation
        {
            (*character_animations[3]).frame_counter++;
            update_animation(*character_animations[3], fps);
            draw_animation(*character_animations[3], screen_width, screen_height);
        }
        else if (guarded == true) // guard animation
        {
            (*character_animations[4]).frame_counter++;
            update_animation(*character_animations[4], fps);
            draw_animation(*character_animations[4], screen_width, screen_height);
        }
        else
        { // all special animations not played then just play idle
            draw_animation(*character_animations[0], screen_width, screen_height);
        }

        // draw all the trees
        draw_animations_type(trees_animations, 3, screen_width, screen_height);

        EndDrawing();
    }
}

// returns true if key for guard is pressed
bool guard()
{
    if (IsKeyPressed(KEY_SPACE) || IsKeyDown(KEY_SPACE))
        return true;
    return false;
}

// increments frame counter of each animation
void update_frame_counter(Animation **&animations, const int &num_animations)
{
    for (int i = 0; i < num_animations; i++)
        (*animations[i]).frame_counter++;
}

void update_animations_type(Animation **&animations, const int &num_animations, const int &fps)
{

    for (int i = 0; i < num_animations; i++)
        update_animation(*animations[i], fps);
}

void draw_animations_type(Animation **&animations, const int &num_animations, const int &screen_width, const int &screen_height)
{

    for (int i = 0; i < num_animations; i++)
    {
        draw_animation(*animations[i], screen_width, screen_height);
    }
}

void update_moving_sheep(Animation &moving_sheep, const int &screen_width, const int &screen_height, float &sheep_speed_X)
{

    Rectangle sheep_rectangle = {moving_sheep.position.x, moving_sheep.position.y,
                                 moving_sheep.frame_rec.width, moving_sheep.frame_rec.height};

    if (moving_sheep.position.x + moving_sheep.frame_rec.width >= screen_width)
    {
        sheep_speed_X *= -1; // go left
        face_animation_left(moving_sheep);
    }
    else if (moving_sheep.position.x <= 0)
    {
        sheep_speed_X *= -1; // go right
        face_animation_right(moving_sheep);
    }

    moving_sheep.position.x += sheep_speed_X;

    // std::cout << "SHEEP position x: " << moving_sheep.position.x << std::endl;
}